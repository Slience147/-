select * from dv_db_om.pub_config where code like 'SpecialProcedureType';
select * from dv_db_om.pub_dict where kind='SpecialProcedureType'; where name like '%�ر�������ͱ���%';
select * from dv_db_om.pub_app_dict where DICT_CODE in ('06156693F4774508AFD03E3EC18EF751','0F0186732B284AB6B418FB9C531D2192');


