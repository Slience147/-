select * from dv_db_fm.xiaoxueruxueersanlei order by MAIN_TBL_PK ;

select * from dv_db_fm.xiaoxueruxueyilei order by MAIN_TBL_PK ;


select case when MAIN_TBL_CONTENT like ''  from dv_db_fm.xiaoxueruxueyilei order by MAIN_TBL_PK ;


select 
from xiaoxueruxueyilei 
where FIND_IN_SET( B.id,  )
GROUP BY A.id  ;

select MAIN_TBL_PK,SUBSTRING(MAIN_TBL_CONTENT,26,11) ������ϵ��ʽ from xiaoxueruxueyilei where MAIN_TBL_CONTENT like '%BeiYongLianXiFangShi%';


select MAIN_TBL_CONTENT from xiaoxueruxueyilei where MAIN_TBL_CONTENT like '%BeiYongLianXiFangShi%';

CREATE TABLE `lilutest` (
  `MAIN_TBL_PK` varchar(32) NOT NULL,
  `MAIN_TBL_CONTENT` longtext,
  `BeiYongLianXiFangShi` longtext,
  `HuJiDiZhi` longtext,
  `HuJiQianRuShiJian` longtext,
  `JianHuRenShenFenZhengHao` longtext,
  `JianHuRenXingMing` longtext,
  `RuXueErTongShenFenZhengHao` longtext,
  `RuXueErTongXingMing` longtext,
  `RuXueErTongYiMiaoJieZhongJieSh` longtext,
  PRIMARY KEY (`MAIN_TBL_PK`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;


select substring(MAIN_TBL_CONTENT,1,POSITION('"',MAIN_TBL_CONTENT)-1) from xiaoxueruxueyilei ;

select substring(MAIN_TBL_CONTENT , 5, POSITION('"' in MAIN_TBL_CONTENT)+10)  from xiaoxueruxueyilei ;

select POSITION('test' in 'this Test is Test') ;

select * from dv_db_fm.xiaoxueruxueyilei order by MAIN_TBL_PK ;
select MAIN_TBL_PK,SUBSTRING(MAIN_TBL_CONTENT,26,11) ������ϵ��ʽ , SUBSTRING(MAIN_TBL_CONTENT,52,30) FangChanFangDianBiaoYongHuBian from xiaoxueruxueyilei ;


select
	substring(MAIN_TBL_CONTENT , position('HuJiDiZhi' in MAIN_TBL_CONTENT)+ 12 ) a ,
	 position('"' in SUBSTRING(MAIN_TBL_CONTENT ,POSITION('HuJiDiZhi' in MAIN_TBL_CONTENT)+12 ) )  b
from
	dv_db_fm.xiaoxueruxueyilei ;


select
	substring(
	substring(MAIN_TBL_CONTENT , position('HuJiDiZhi' in MAIN_TBL_CONTENT)+ 12 )   --Ҫ��ȡ���ַ���
	, 1  --��ʼ�±�
	, position('"' in SUBSTRING(MAIN_TBL_CONTENT ,POSITION('HuJiDiZhi' in MAIN_TBL_CONTENT)+12 ) )-1 )  --����
from
	dv_db_fm.xiaoxueruxueyilei ;

--HuJiQianRuShiJian

select
	substring(
	substring(MAIN_TBL_CONTENT , position('HuJiQianRuShiJian' in MAIN_TBL_CONTENT)+ 12 ) 
	, 1  
	, position('"' in SUBSTRING(MAIN_TBL_CONTENT ,POSITION('HuJiQianRuShiJian' in MAIN_TBL_CONTENT)+12 ) )-1 )  
from
	dv_db_fm.xiaoxueruxueyilei ;

select  substring(
substring(MAIN_TBL_CONTENT , position('HuJiQianRuShiJian' in MAIN_TBL_CONTENT)+ 20 ) ,
1,
10
)
from
	dv_db_fm.xiaoxueruxueyilei ;


select
MAIN_TBL_PK,
substring(MAIN_TBL_CONTENT , position('JianHuRenHuKouHuZhuXingMing' in MAIN_TBL_CONTENT) ) ,
	substring(
	substring(MAIN_TBL_CONTENT , position('JianHuRenHuKouHuZhuXingMing' in MAIN_TBL_CONTENT)+ 30 )  
	, 1  
	, position('"' in SUBSTRING(MAIN_TBL_CONTENT ,POSITION('JianHuRenHuKouHuZhuXingMing' in MAIN_TBL_CONTENT)+30 ) )-1 ) 
from
	dv_db_fm.xiaoxueruxueyilei ;



