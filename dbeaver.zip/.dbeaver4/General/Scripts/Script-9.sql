select * from pub_user where name='��ƽ'
539AE6937AF0418088F910A50B5EA15A

select * from doc_disk where owner_id='539AE6937AF0418088F910A50B5EA15A' ;

select * from dv_db_wf.act_business_index where BUSINESS_KEY = '3605E1A520191220000013' ;

--XinYuShiShouCiDengJiZheng XinYuShiShouCiDengJi ;

select * from dv_db_fm.shoucidengjixinyushi ;
--XinYuShiShouCiDengJiZheng
drop table dv_db_fm.shoucidengjixinyushi ;

select * from dv_db_fm. ;

CREATE TABLE dv_db_fm.`XinYuShiShouCiDengJiZheng` (
  `MAIN_TBL_PK` varchar(32) NOT NULL,
  `MAIN_TBL_CONTENT` longtext,
  PRIMARY KEY (`MAIN_TBL_PK`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

show variables like 'max_allowed_packet';

select * from dv_db_fm.XinYuShiShiJianJuYiLiaoQiXieEr ;

alter  table table1 modify  column column1  decimal(10,1) DEFAULT NULL COMMENT 'ע��';

alter table dv_db_fm.XinYuShiShiJianJuYiLiaoQiXieEr type = InnoDB;

show table status from dv_db_fm  ;

select * from dv_db_fm.XinYuShiShiJianJuYiLiaoQiXieEr where MAIN_TBL_CONTENT = '20200707163804818900' ;

select * from dv_db_fm.xiangguanzhenghao20200820 ;

drop table dv_db_fm.quanliren20200820 ;

CREATE TABLE `xiangguanzhenghao20200820` (
  `SUB_TBL_PK` varchar(32) NOT NULL,
  `MAIN_TBL_PK` varchar(32) NOT NULL,
  `SUB_TBL_NUM` int(11) DEFAULT NULL,
  PRIMARY KEY (`SUB_TBL_PK`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;


dv_db_fm.quanliren20200820
quanliren20200820
quanliren20200820
xiangguanzhenghao20200820
QuanLiRen20200820 







