select * from test.`user` ;

drop table mytest.`user` ;
CREATE TABLE `user` (
  `id` varchar(255) NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `password` varchar(255) DEFAULT NULL
) DEFAULT CHARSET=utf8;


INSERT INTO test.person
(id, name, password)
VALUES('3', 'ming', '111');

select * from person ;

alter table test.person type = MyISAM ;
alter table person type = MyISAM;

show table status from test;

select POSITION('test' in 'this Test is Test') ;

