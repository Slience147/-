select * from dv_db_om_dd.pub_dict where KIND = 'SpecialProcedureType' ; 

select * from dv_db_om.pub_dict where KIND = 'SpecialProcedureType' ; 

/*delete from dv_db_wf.ACT_BUSINESS_INDEX  where BUSINESS_KEY='3611686C20200810000299';    */
