select * from dv_db_fm.zinvxinxi ;

drop table dv_db_fm.shengyudengjibiaodanyilian1 ; 

