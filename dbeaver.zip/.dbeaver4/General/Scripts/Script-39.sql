select * from dv_db_wf.act_business_index where BUSINESS_KEY = '360120200604000170' ;

delete from dv_db_wf.act_business_index where BUSINESS_KEY = '360120200928000056' ;

select * from dv_db_om.pub_user_lock ;

select * from dv_db_wf.act_business_index where BUSINESS_KEY = '360120200928000056';

select * from dv_db_rc.doc_disk where OWNER_ID = '0CE2E630E3924A97BEF0496E8EE60FA2' ;


select * from dv_db_wf.act_business_index where BUSINESS_KEY = '36010120201021000160' ;

---delete from dv_db_wf.act_business_index where BUSINESS_KEY = '36010120201021000160' ;


