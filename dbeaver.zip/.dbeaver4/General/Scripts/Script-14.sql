select * from pub_dict where kind = 'dataSourceType' and name ='Oracle12c'
delete  from  pub_dict where CODE = 'dataSourceType'
 
select * from pub_config where CODE ='datasourceType'
delete  from  pub_config where CODE = 'dataSourceType'

select * from pub_data_resource where CODE ='datasourceType'

select * from pub_app_dict 

--�������ݿ�mysql�еı���
select * from dv_db_wf_20170216.act_business_index where BUSINESS_KEY ='3600679220191029000004';

delete from dv_db_wf_20170216.act_business_index where BUSINESS_KEY='3600679220191029000004';

select distinct APP_CODE from dv_db_fm.cf_form 

ALTER TABLE dv_db_om.PUB_USER ADD SORT_ORDER int(11)  DEFAULT '1' ;

ALTER TABLE dv_db_fm.xinyushishijianjuyiliaoqixieer ENGINE=MyISAM;

select * from dv_db_fm_20170216.ceshitupianshangchuan ;

ALTER TABLE dv_db_fm_20170216.ceshitupianshangchuan ENGINE=MyISAM ;

select * from dv_db_fm_20170216.SheHuiJiuZhuShenQingBiao ;

select * from dv_db_fm_20170216.SheHuiJiuZhuShenQingBiao ;

select * from dv_db_fm_20170216.A_SYS_BASIC;
select * from dv_db_fm_20170216.DiYaQuanRenZhengShi0;

drop table dv_db_fm_20170216.DiYaQuanRenZhengShi0 ;
drop table dv_db_fm_20170216.DiYaQuanRenDaiLiRenZhengShi0;
drop table dv_db_fm_20170216.DiYaRenZhengShi0 ;
drop table dv_db_fm_20170216.DiYaRenDaiLiRenZhengShi0 ;
drop table dv_db_fm_20170216.XiangGuanZhengHaoZhengShiDiYa3 ;

drop table dv_db_fm_20170216.DiYaQuanRenZhengShi4 ;
drop table dv_db_fm_20170216.DiYaQuanRenDaiLiRenZhengShi4;
drop table dv_db_fm_20170216.DiYaRenZhengShi4 ;
drop table dv_db_fm_20170216.DiYaRenDaiLiRenZhengShi4 ;
drop table dv_db_fm_20170216.XiangGuanZhengHaoZhengShiDiYa4 ;

drop table dv_db_fm_20170216.IDXinYuZhuanYiDengJi20200820 ;
drop table dv_db_fm_20170216.DiYa20200824;
drop table dv_db_fm_20170216.DiYaRenZhengShi4 ;
drop table dv_db_fm_20170216.DiYaRenDaiLiRenZhengShi4 ;
drop table dv_db_fm_20170216.XiangGuanZhengHaoZhengShiDiYa5 ;

select * from dv_db_fm_20170216.XinYuShiDiYa20200526 ; 

select * from dv_db_om_dd.pub_dict where KIND = 'SpecialProcedureType' ; 
select * from dv_db_om_dd.pub_app_dict where KIND = 'SpecialProcedureType' ; 
select * from dv_db_om_dd where KIND = 'SpecialProcedureType' ; 


select * from pub_config where code like 'SpecialProcedureType';
select * from pub_dict where kind='SpecialProcedureType'; where name like '%�ر�������ͱ���%';
select * from pub_app_dict where DICT_CODE in ('06156693F4774508AFD03E3EC18EF751','0F0186732B284AB6B418FB9C531D2192');

select * from dv_db_fm_20170216.ShengJiaoTongTingXingZhengShen;
drop table dv_db_fm_20170216.ShengJiaoTongTingXingZhengShen;

--06156693F4774508AFD03E3EC18EF751
--0F0186732B284AB6B418FB9C531D2192

select * from dv_db_om.pub_app_dict where KIND = 'S620TA-A4BH';

select * from dv_db_fm_20170216.JingDeZhenShiZhuanYiDengJi ;
select * from dv_db_fm_20170216.XiangGuanZhengHaoZhuanYi ;
select * from dv_db_fm_20170216.QuanLiRenZhuanYi ;
select * from dv_db_fm_20170216.QuanLiRenDaiLiRenZhuanYi ;
select * from dv_db_fm_20170216.YiWuRenZhuanYi ;
select * from dv_db_fm_20170216.YiWuRenDaiLiRenZhuanYi ;

drop table dv_db_fm_20170216.QuanLiRenZhuanYi ;
drop table dv_db_fm_20170216.QuanLiRenDaiLiRenZhuanYi ;
drop table dv_db_fm_20170216.YiWuRenZhuanYi ;
drop table dv_db_fm_20170216.YiWuRenDaiLiRenZhuanYi ;



