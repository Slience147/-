DELETE FROM act_business_index WHERE BUSINESS_KEY = '2020043001005' ;

select * FROM act_business_index WHERE BUSINESS_KEY = '2020043001005' ;

