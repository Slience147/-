select * from dv_db_om.pub_organ where code='360122000201047000';

